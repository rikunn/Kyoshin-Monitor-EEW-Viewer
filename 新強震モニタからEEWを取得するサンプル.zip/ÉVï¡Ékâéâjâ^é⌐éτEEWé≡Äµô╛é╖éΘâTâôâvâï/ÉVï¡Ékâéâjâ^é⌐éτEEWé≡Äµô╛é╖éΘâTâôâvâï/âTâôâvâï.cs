﻿using Newtonsoft.Json;
using System.Net;
using System.Globalization;
//上・必要なusing

using System;
using System.Text;
using System.Windows.Forms;

namespace 新強震モニタからEEWを取得するサンプル
{
    public partial class サンプル : Form
    {
        public サンプル()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
			//強震モニタから現在時刻を取得するサンプル　
			try
			{
				string json;
				using (WebClient wc = new WebClient())
				{
					wc.Encoding = Encoding.UTF8;
					json = wc.DownloadString("http://www.kmoni.bosai.go.jp/webservice/server/pros/latest.json");
					Monitorjson jsonData = JsonConvert.DeserializeObject<Monitorjson>(json);
					//1.現在時刻
					string KyoshinTime = jsonData.request_time;
					//2.現在時刻から1秒ずらした
					string KyoshinTime2 = jsonData.latest_time;
					DateTime dt;
					DateTime.TryParseExact(KyoshinTime, "yyyy/MM/dd HH:mm:ss", null, DateTimeStyles.None, out dt);
					//1の使い方＝http://www.kmoni.bosai.go.jp/webservice/hypo/eew/" + dt.AddSeconds(-1).ToString("yyyyMMddHHmmss") + ".json
					//2の使い方＝http://www.kmoni.bosai.go.jp/webservice/hypo/eew/" + dt.ToString("yyyyMMddHHmmss") + ".json
				}
			}
			catch { }


			//強震モニタからEEWを取得するサンプル
			try
			{
				string json;
				using (WebClient wc = new WebClient())
				{
					wc.Encoding = Encoding.UTF8;
					//タイムオブジェクトを作成
					var EEWTime = DateTime.Now.ToString("yyyyMMddHHmmss");
					json = wc.DownloadString("http://www.kmoni.bosai.go.jp/webservice/hypo/eew/" + EEWTime + ".json");
				}
				bool flag = json.Contains("ありません");
				if (flag)
				{
                    //緊急地震速報が発表されてない時の動作
				}
				else
				{
					//緊急地震速報が発表されている時の動作

					EEWjson jsonData = JsonConvert.DeserializeObject<EEWjson>(json);

					//最終報か       jsonData.Is_final;

					//第何報か       jsonData.Report_num;

					//地震発生時刻   jsonData.Origin_time;

					//震源           jsonData.Region_name;

					//深さ           jsonData.request_time;

					//マグニチュード jsonData.Magnitude;

					//最大震度       jsonData.Calcintensity;

				//緊急地震速報種類   jsonData.Alertflg;
				}
			}
            catch { }


		}
    }
}
