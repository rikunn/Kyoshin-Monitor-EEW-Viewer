﻿namespace 新強震モニタからEEWを取得するサンプル
{
    internal class Monitorjson
    {
        public string latest_time { get; set; }
        public string request_time { get; set; }
    }
}