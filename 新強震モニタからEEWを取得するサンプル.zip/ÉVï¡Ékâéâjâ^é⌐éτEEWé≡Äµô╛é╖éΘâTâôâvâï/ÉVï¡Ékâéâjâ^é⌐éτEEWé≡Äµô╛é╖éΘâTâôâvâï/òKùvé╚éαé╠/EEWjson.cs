﻿using Newtonsoft.Json;

namespace 新強震モニタからEEWを取得するサンプル
{
    internal class EEWjson
    {
		[JsonProperty("report_time")]
		public string Report_time { get; set; }

		[JsonProperty("region_code")]
		public string Region_code { get; set; }

		[JsonProperty("request_time")]
		public string Request_time { get; set; }

		[JsonProperty("region_name")]
		public string Region_name { get; set; }

		[JsonProperty("longitude")]
		public string Longitude { get; set; }

		[JsonProperty("is_cancel")]
		public bool Is_cancel { get; set; }

		[JsonProperty("depth")]
		public string request_time { get; set; }

		[JsonProperty("calcintensity")]
		public string Calcintensity { get; set; }

		[JsonProperty("is_final")]
		public bool Is_final { get; set; }

		[JsonProperty("is_training")]
		public bool Is_training { get; set; }

		[JsonProperty("latitude")]
		public string Latitude { get; set; }

		[JsonProperty("origin_time")]
		public string Origin_time { get; set; }

		[JsonProperty("magunitude")]
		public string Magnitude { get; set; }

		[JsonProperty("report_num")]
		public string Report_num { get; set; }

		[JsonProperty("request_hypo_type")]
		public string Request_hypo_type { get; set; }

		[JsonProperty("report_id")]
		public string Report_id { get; set; }

		[JsonProperty("alertflg")]
		public string Alertflg { get; set; }

		public class Results
		{
			[JsonProperty("status")]
			public string Status { get; set; }

			[JsonProperty("message")]
			public string Message { get; set; }

			[JsonProperty("is_auth")]
			public bool Is_auth { get; set; }

		}
		public class Securities
		{
			[JsonProperty("realm")]
			public string Realm { get; set; }

			[JsonProperty("hash")]
			public string Hash { get; set; }

		}
	}
}